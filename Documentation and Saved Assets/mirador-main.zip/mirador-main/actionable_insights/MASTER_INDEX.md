# MIRADOR ACTIONABLE INSIGHTS MASTER INDEX
Generated: Sun Jun  8 01:32:38 EDT 2025

## Overview
This index organizes all insights extracted from Mirador chains for easy reference and action.

---

### Immediate (56 insights)

- chain_20250605_190920.md
- chain_20250605_225803.md
- chain_20250606_081706.md
- chain_20250606_083123.md
- chain_20250606_085008.md

### Short Term (38 insights)

- chain_20250605_124444.md
- chain_20250605_125723.md
- chain_20250605_130952.md
- chain_20250605_190418.md
- chain_20250605_195453.md

### Long Term (12 insights)

- chain_20250606_083439.md
- chain_20250606_113738.md
- chain_20250607_092419.md
- chain_20250607_092758.md
- chain_20250607_093231.md

### Financial (101 insights)

- chain_20250605_124444.md
- chain_20250605_125723.md
- chain_20250605_130952.md
- chain_20250605_185032.md
- chain_20250605_190920.md

### Career (87 insights)

- chain_20250605_124444.md
- chain_20250605_125723.md
- chain_20250605_130952.md
- chain_20250605_185032.md
- chain_20250605_190920.md

### Business (65 insights)

- chain_20250605_003042.md
- chain_20250605_074035.md
- chain_20250605_124444.md
- chain_20250605_125723.md
- chain_20250605_190418.md

### Real Estate (66 insights)

- chain_20250605_124444.md
- chain_20250605_125723.md
- chain_20250605_185032.md
- chain_20250605_190920.md
- chain_20250605_195453.md

