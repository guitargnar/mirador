=== Complete Model List ===
ai_content_strategist:latest
business_strategist_fast:latest
code_reviewer_fix:latest
code_reviewer:latest
codellama:latest
content_strategist_pro:latest
creative_entrepreneur:latest
decision_enhancer:latest
decision_simplifier_v2:latest
decision_simplifier:latest
deepseek-coder-lowtemp:latest
deepseek-coder:latest
deepseek-extended:latest
digital_storyteller:latest
engagement_optimizer:latest
enhanced_agent_builder:latest
enhanced_agent_enforcer:latest
enhanced_agent_fast_v2:latest
enhanced_agent_fast_v3:latest
enhanced_agent_fast_v4:latest
enhanced_agent_fast_v5:latest
enhanced_agent_fast_v6:latest
enhanced_agent_fast_v7:latest
enhanced_agent_fast:latest
enhanced_agent_v2:latest
enhanced_agent:latest
fast_agent_focused:latest
fast_agent_llama:latest
fast_agent_ultimate:latest
file_reviewer:latest
financial_planning_expert_fast:latest
financial_planning_expert_v2:latest
financial_planning_expert_v3:latest
financial_planning_expert_v4:latest
financial_planning_expert_v5:latest
financial_planning_expert_v6:latest
financial_planning_expert_v7:latest
financial_planning_expert:latest
guitar_expert_precise:latest
health_wellness_optimizer:latest
life_transition_coordinator:latest
linkedin_content_expert:latest
linkedin_thought_leader:latest
llama3.2_balanced:latest
llama3.2:latest
louisville_expert_v2:latest
louisville_expert_v3:latest
louisville_expert:latest
master_coder:latest
matthew_context_provider_v2:latest
matthew_context_provider:latest
matthews_linkedin_voice:latest
mirador_system_specialist_v2:latest
mirador_system_specialist:latest
mistral:latest
my-persistent-agent:latest
opportunity_analyst:latest
opportunity_validator_v2:latest
parenting_decision_support:latest
personal_brand_architect:latest
productivity_optimizer:latest
real_estate_analyzer:latest
relationship_communication_specialist:latest
sales_content_creator:latest
ux_designer:latest

=== Model Family Summary ===
   7 financial_planning_expert
   7 enhanced_agent_fast
   3 louisville_expert
   2 mirador_system_specialist
   2 matthew_context_provider
   2 enhanced_agent
   2 decision_simplifier
   1 ux_designer
   1 sales_content_creator
   1 relationship_communication_specialist
   1 real_estate_analyzer
   1 productivity_optimizer
   1 personal_brand_architect
   1 parenting_decision_support
   1 opportunity_validator
   1 opportunity_analyst
   1 my-persistent-agent
   1 mistral
   1 matthews_linkedin_voice
   1 master_coder
   1 llama3.2_balanced
   1 llama3.2
   1 linkedin_thought_leader
   1 linkedin_content_expert
   1 life_transition_coordinator
   1 health_wellness_optimizer
   1 guitar_expert_precise
   1 financial_planning_expert_fast
   1 file_reviewer
   1 fast_agent_ultimate
   1 fast_agent_llama
   1 fast_agent_focused
   1 enhanced_agent_enforcer
   1 enhanced_agent_builder
   1 engagement_optimizer
   1 digital_storyteller
   1 deepseek-extended
   1 deepseek-coder-lowtemp
   1 deepseek-coder
   1 decision_enhancer
   1 creative_entrepreneur
   1 content_strategist_pro
   1 codellama
   1 code_reviewer_fix
   1 code_reviewer
   1 business_strategist_fast
   1 ai_content_strategist

=== Modelfiles in Project Directory ===
-rw-r--r--  1 matthewscott  staff   872 Jun  8 07:33 content_strategist_pro.modelfile
-rw-r--r--  1 matthewscott  staff   564 Jun 12 15:21 decision_enhancer.modelfile
-rw-r--r--  1 matthewscott  staff   806 Jun 13 05:53 decision_simplifier_v2.modelfile
-rw-r--r--  1 matthewscott  staff   870 Jun  8 07:33 digital_storyteller.modelfile
-rw-r--r--  1 matthewscott  staff  1444 Jun  8 07:54 engagement_optimizer.modelfile
-rw-r--r--  1 matthewscott  staff  1329 Jun 13 05:53 enhanced_agent_enforcer.modelfile
-rw-r--r--  1 matthewscott  staff  1085 Jun  5 18:45 enhanced_agent_fast_v2.modelfile
-rw-r--r--  1 matthewscott  staff  1279 Jun  6 08:43 enhanced_agent_fast_v3.modelfile
-rw-r--r--  1 matthewscott  staff  1281 Jun  7 09:37 enhanced_agent_fast_v4.modelfile
-rw-r--r--  1 matthewscott  staff  1546 Jun  7 09:59 enhanced_agent_fast_v5.modelfile
-rw-r--r--  1 matthewscott  staff  1270 Jun 13 05:52 enhanced_agent_fast_v6.modelfile
-rw-r--r--  1 matthewscott  staff   332 Jun 12 15:20 enhanced_agent_fast_v7.modelfile
-rw-r--r--  1 matthewscott  staff   291 Jun 12 15:20 financial_planning_expert_fast.modelfile
-rw-r--r--  1 matthewscott  staff  1528 Jun  5 18:46 financial_planning_expert_v2.modelfile
-rw-r--r--  1 matthewscott  staff  1851 Jun  6 08:44 financial_planning_expert_v3.modelfile
-rw-r--r--  1 matthewscott  staff  1866 Jun  6 08:49 financial_planning_expert_v4.modelfile
-rw-r--r--  1 matthewscott  staff  1618 Jun  7 14:50 financial_planning_expert_v5.modelfile
-rw-r--r--  1 matthewscott  staff  1338 Jun 13 05:52 financial_planning_expert_v6.modelfile
-rw-r--r--  1 matthewscott  staff  1104 Jun  6 22:12 financial_planning_expert_v7.modelfile
-rw-r--r--  1 matthewscott  staff   992 Jun  8 08:26 health_wellness_optimizer.modelfile
-rw-r--r--  1 matthewscott  staff  1274 Jun  8 07:33 linkedin_content_expert.modelfile
-rw-r--r--  1 matthewscott  staff  1289 Jun 13 05:53 louisville_expert_v2.modelfile
-rw-r--r--  1 matthewscott  staff   809 Jun 11 11:13 louisville_expert_v3.modelfile
-rw-r--r--  1 matthewscott  staff  2324 Jun 13 11:46 matthew_context_provider_v2.modelfile
-rw-r--r--  1 matthewscott  staff   949 Jun 13 05:53 matthew_context_provider.modelfile
-rw-r--r--  1 matthewscott  staff  2192 Jun 13 11:46 mirador_system_specialist_v2.modelfile
-rw-r--r--  1 matthewscott  staff  1662 Jun 11 10:57 mirador_system_specialist.modelfile
-rw-r--r--  1 matthewscott  staff  1123 Jun  6 22:14 opportunity_analyst.modelfile
-rw-r--r--  1 matthewscott  staff  1457 Jun 11 17:23 opportunity_validator_v2.modelfile
-rw-r--r--  1 matthewscott  staff  1338 Jun  8 07:54 personal_brand_architect.modelfile
-rw-r--r--  1 matthewscott  staff   949 Jun  8 08:26 productivity_optimizer.modelfile
-rw-r--r--  1 matthewscott  staff  1332 Jun  8 07:54 sales_content_creator.modelfile

=== Modelfiles in Home Directory ===
/Users/matthewscott/decision_simplifier.modelfile
/Users/matthewscott/enhanced_agent_adapted.modelfile
/Users/matthewscott/enhanced_agent_enforcer.modelfile
/Users/matthewscott/enhanced_agent_v2.modelfile
/Users/matthewscott/fast_agent_focused_adapted.modelfile
/Users/matthewscott/fast_agent_llama.modelfile
/Users/matthewscott/fast_agent_ultimate.modelfile
/Users/matthewscott/fast_agent_v2.modelfile
/Users/matthewscott/fast_agent_v3.modelfile
/Users/matthewscott/fast_agent_v4.modelfile
/Users/matthewscott/matthews_linkedin_voice.modelfile
/Users/matthewscott/relationship_communication_specialist.modelfile
